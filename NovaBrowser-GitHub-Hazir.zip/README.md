# Nova Browser

Android 14 uyumlu, modern arayüzlü WebView tabanlı tarayıcı başlangıç projesi.

## Özellikler
- Adres çubuğu ve Google araması
- Geri/ileri, yenileme ve ana sayfa
- Koyu renkli tarayıcı kabuğu
- Üçüncü taraf çerezlerini kapatma
- Başlangıç seviyesinde alan adı tabanlı reklam/izleyici engelleme kalkanı
- GitHub Actions ile APK derleme

## GitHub'a yükleme (telefondan)
1. GitHub'da yeni, **boş** bir depo (repository) oluştur (README eklemeden).
2. Depo sayfasında **"uploading an existing file"** linkine tıkla.
3. Bu ZIP'i açtığında çıkan **tüm dosya ve klasörleri** (`.github`, `app`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `.gitignore`, `README.md`) seç ve sürükleyip bırak ya da "choose your files" ile yükle.
   - Önemli: Klasörlerin **içeriğini** değil, `app` ve `.github` klasörlerinin **kendisini** yüklemelisin ki depo kökünde `app/...` ve `.github/...` yolları oluşsun.
   - GitHub mobil tarayıcıda klasör sürüklemek zor olabilir; bilgisayar yoksa GitHub'ın mobil uygulamasını ya da "Add file → Upload files" ekranını kullanıp tüm dosyaları tek seferde seçmeyi dene (ZIP dosyasının kendisini değil, içindekileri).
4. Değişiklikleri **main** dalına commit et.

## APK oluşturma
1. Depoda **Actions** sekmesine gir.
2. `Build Nova Browser APK` iş akışını seç ve **Run workflow** düğmesine bas (dosyaları `main`'e gönderince de otomatik başlar).
3. İşlem tamamlanınca çalışmanın altındaki **Artifacts** bölümünden `NovaBrowser-debug-apk` dosyasını indir.
4. İndirilen ZIP içindeki `app-debug.apk` dosyasını telefonuna aktar ve kur (bilinmeyen kaynaklardan yükleme izni gerekebilir).

## Önemli reklam engelleme notu
Bu sürüm, bilinen bazı reklam/izleyici alan adlarını istek yakalama sırasında engelleyen bir başlangıç kalkanıdır. Brave Shields ile aynı seviyede değildir: EasyList/EasyPrivacy gibi düzenli güncellenen filtre listelerinin tam ayrıştırılması, sayfa içi (cosmetic) filtreler, gelişmiş yönlendirme/istisna kuralları ve sayaçların iyileştirilmesi sonraki geliştirme adımlarıdır. WebView tabanlı mimarinin de Chromium tabanlı Brave ile aynı ağ ve motor denetimlerini sağlamadığını unutma.
