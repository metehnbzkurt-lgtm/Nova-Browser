package com.novabrowser.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayInputStream
import java.net.URI
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var addressBar: EditText
    private lateinit var shieldButton: Button
    private lateinit var statusText: TextView
    private var shieldsEnabled = true
    private var blockedCount = 0

    private val homeUrl = "https://www.google.com"
    private val blockedHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "adform.net", "taboola.com",
        "outbrain.com", "scorecardresearch.com", "adcolony.com",
        "app-measurement.com", "analytics.google.com", "connect.facebook.net",
        "facebook.net", "hotjar.com", "mixpanel.com", "segment.io",
        "quantserve.com", "ads-twitter.com", "ads.linkedin.com"
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 22, 29)
        window.navigationBarColor = Color.rgb(18, 22, 29)
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(18, 22, 29))
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(10), dp(6))
        }
        val brand = TextView(this).apply {
            text = "◈  NOVA"
            textSize = 18f
            setTextColor(Color.WHITE)
            letterSpacing = 0.08f
        }
        brandRow.addView(brand, LinearLayout.LayoutParams(0, dp(38), 1f))
        shieldButton = Button(this).apply {
            text = "🛡 Kalkan açık"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(37, 110, 83)))
            setOnClickListener {
                shieldsEnabled = !shieldsEnabled
                updateShieldButton()
                Toast.makeText(this@MainActivity,
                    if (shieldsEnabled) "Engelleme açık" else "Engelleme kapalı",
                    Toast.LENGTH_SHORT).show()
                webView.reload()
            }
        }
        brandRow.addView(shieldButton)
        root.addView(brandRow)

        val addressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(2), dp(10), dp(8))
        }
        addressBar = EditText(this).apply {
            hint = "Ara veya web adresi yaz"
            singleLine = true
            textSize = 15f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(dp(14), 0, dp(10), 0)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(54, 62, 75)))
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                    navigate(addressBar.text.toString()); true
                } else false
            }
        }
        addressRow.addView(addressBar, LinearLayout.LayoutParams(0, dp(48), 1f))
        val goButton = Button(this).apply {
            text = "Git"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setOnClickListener { navigate(addressBar.text.toString()) }
        }
        addressRow.addView(goButton)
        root.addView(addressRow)

        webView = WebView(this)
        webView.setBackgroundColor(Color.WHITE)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadsImagesAutomatically = true
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = true
            displayZoomControls = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false)
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                statusText.text = "Kalkan • $blockedCount engellendi • $newProgress%"
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (request.isForMainFrame) addressBar.setText(url)
                return false
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return null
                if (!shieldsEnabled || url.host.isNullOrBlank()) return null
                val host = url.host!!.lowercase(Locale.ROOT)
                val blocked = blockedHosts.any { host == it || host.endsWith(".$it") }
                if (blocked) {
                    synchronized(this@MainActivity) { blockedCount++ }
                    return WebResourceResponse(
                        "text/plain", "utf-8", 204, "No Content",
                        mapOf("Access-Control-Allow-Origin" to "*"),
                        ByteArrayInputStream(ByteArray(0))
                    )
                }
                return null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                if (url != null) addressBar.setText(url)
                blockedCount = 0
                statusText.text = "Sayfa yükleniyor…"
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url != null) addressBar.setText(url)
                statusText.text = "Kalkan • $blockedCount engellendi"
            }
        }
        root.addView(webView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setBackgroundColor(Color.rgb(25, 30, 39))
        }
        fun navButton(label: String, action: () -> Unit) {
            val b = Button(this).apply {
                text = label
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(25, 30, 39)))
                setOnClickListener { action() }
            }
            bottom.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        navButton("←") { if (webView.canGoBack()) webView.goBack() }
        navButton("Ana sayfa") { webView.loadUrl(homeUrl) }
        navButton("İleri →") { if (webView.canGoForward()) webView.goForward() }
        navButton("Yenile") { webView.reload() }
        root.addView(bottom)

        statusText = TextView(this).apply {
            text = "Nova hazır"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            setPadding(dp(12), dp(3), dp(12), dp(6))
            setBackgroundColor(Color.rgb(25, 30, 39))
        }
        root.addView(statusText)
        setContentView(root)
        updateShieldButton()
        webView.loadUrl(homeUrl)
    }

    private fun updateShieldButton() {
        shieldButton.text = if (shieldsEnabled) "🛡 Kalkan açık" else "Kalkan kapalı"
        shieldButton.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(
                if (shieldsEnabled) Color.rgb(37, 110, 83) else Color.rgb(90, 68, 45)
            )
        )
    }

    private fun navigate(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return
        val url = if (value.contains(" ") || (!value.contains(".") && !value.startsWith("http"))) {
            "https://www.google.com/search?q=" + java.net.URLEncoder.encode(value, "UTF-8")
        } else if (value.startsWith("https://") || value.startsWith("http://")) value
        else "https://$value"
        webView.loadUrl(url)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
