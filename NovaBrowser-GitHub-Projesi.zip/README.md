# Nova Browser

Android 14 uyumlu, modern arayüzlü WebView tabanlı tarayıcı başlangıç projesi.

## Özellikler
- Adres çubuğu ve Google araması
- Geri/ileri, yenileme ve ana sayfa
- Koyu renkli tarayıcı kabuğu
- Üçüncü taraf çerezlerini kapatma
- Başlangıç seviyesinde alan adı tabanlı reklam/izleyici engelleme kalkanı
- GitHub Actions ile APK derleme

## APK oluşturma (telefondan GitHub)
1. Bu ZIP'i aç ve içindeki `NovaBrowser` klasörünün **içeriğini** yeni GitHub deposuna yükle. `app`, `.github`, `build.gradle.kts`, `settings.gradle.kts` gibi dosyalar deponun kökünde olmalı.
2. GitHub deposunda **Actions** sekmesine gir.
3. `Build Nova Browser APK` iş akışını seç ve **Run workflow** düğmesine bas (veya `main` dalına dosya gönder).
4. İşlem tamamlanınca çalışmanın altındaki **Artifacts** bölümünden `NovaBrowser-debug-apk` dosyasını indir.
5. ZIP içindeki `app-debug.apk` dosyasını GM24 Pro'ya aktar ve kur.

## Önemli reklam engelleme notu
Bu sürüm, bilinen bazı reklam/izleyici alan adlarını istek yakalama sırasında engelleyen bir başlangıç kalkanıdır. Brave Shields ile aynı seviyede değildir: EasyList/EasyPrivacy gibi düzenli güncellenen filtre listelerinin tam ayrıştırılması, sayfa içi (cosmetic) filtreler, gelişmiş yönlendirme/istisna kuralları ve sayaçların iyileştirilmesi sonraki geliştirme adımlarıdır. WebView tabanlı mimarinin de Chromium tabanlı Brave ile aynı ağ ve motor denetimlerini sağlamadığını unutma.
